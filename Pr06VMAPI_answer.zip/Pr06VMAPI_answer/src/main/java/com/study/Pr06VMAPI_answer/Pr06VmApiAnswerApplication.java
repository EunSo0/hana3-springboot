package com.study.Pr06VMAPI_answer;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Pr06VmApiAnswerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Pr06VmApiAnswerApplication.class, args);
	}

}
