package com.study.Pr06VMAPI_answer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Pr06VmApiAnswerApplicationTests {

	@Test
	void contextLoads() {
	}

}
