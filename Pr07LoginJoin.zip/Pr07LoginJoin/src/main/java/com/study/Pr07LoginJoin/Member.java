package com.study.Pr07LoginJoin;

import lombok.Data;
import org.springframework.cglib.core.Local;
import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Data
public class Member {
  private String username;
  private String password;
  private String email;
  private LocalDate joindate;

  public Member(String inputName, String inputEmail, String inputPw, LocalDate joindate) {
    this.username = inputName;
    this.email = inputEmail;
    this.password = inputPw;
    this.joindate = joindate;
  }
}