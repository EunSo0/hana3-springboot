package com.study.Pr07LoginJoin;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cglib.core.Local;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Controller
@RequiredArgsConstructor
public class MainController {
  List<Member> memberList = new ArrayList<>();

  @GetMapping("/")
  public String index() {
    return "redirect:/login";
  }

  @GetMapping("/login")
  public String login(Model model) {
    return "login";
  }

  @PostMapping("/login")
  public String login(@RequestParam String inputName, @RequestParam String inputPw, Model model) {
    boolean isLogin = false;
    for(Member m : memberList) {
      if(m.getUsername().equals(inputName) && m.getPassword().equals(inputPw)){
        isLogin = true;
        break;
      }
    }
    if(isLogin) {
      model.addAttribute("login_status", "로그인 성공!");
    } else {
      model.addAttribute("login_status", "로그인 실패");
    }
    return "login";
  }

  @GetMapping("/join")
  public String join() {
    return "join";
  }

  @PostMapping("/join")
  public String join(@RequestParam String inputName, @RequestParam String inputEmail,
                     @RequestParam String inputPw, @RequestParam String inputPw2,
                     Model model){

    if(inputPw.equals(inputPw2)){
      memberList.add(new Member(inputName, inputEmail, inputPw, LocalDate.now()));
      model.addAttribute("login_status", "회원가입 성공!");
    }

    return "login";
  }

  @PostMapping("/duple")
  public String duple(@RequestParam String inputName, Model model){
    boolean isDuple = false;
    for(Member m : memberList){
      if(m.getUsername().equals(inputName)){
        isDuple = true;
        break;
      }
    }
    if(isDuple){
      model.addAttribute("duple_status", "중복된 아이디가 있습니다.");
    } else{
      model.addAttribute("inputName", inputName);
      model.addAttribute("duple_status", "사용할 수 있는 아이디입니다.");
    }
    return "join";
  }
}
